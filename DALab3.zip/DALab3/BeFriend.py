from py2neo import Graph, Node, Relationship
g = Graph("bolt://localhost:7687", auth = ("neo4j", "010403"))
path = "C:/Users/xiexiaoxiao/Desktop/facebook/"
i = 0
for line in open(path+"0.edges") :
    data = line.split(" ")
    g.run("MERGE (a: Person {name : "+data[0]+"}) \n MERGE (b: Person {name : "+data[1]+"}) \n MERGE (a)-[:Be_Friend_With]->(b)")
    i=i+1
    if i%100==0:
        print(i)