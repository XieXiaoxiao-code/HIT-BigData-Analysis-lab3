from py2neo import Graph, Node, Relationship
g = Graph("bolt://localhost:7687", auth = ("neo4j", "010403"))
path = "C:/Users/xiexiaoxiao/Desktop/facebook/"
n = 0
for line in open(path+"0.circles") :
    data = line.split("	")
    for i in range(1, len(data)):
        for j in range(1, len(data)):
            g.run("MERGE (a: Person {name : "+data[i]+"}) \n MERGE (b: Person {name : "+data[j]+"}) \n MERGE (a)-[:Be_Circle_With]->(b)")
            n=n+1
            if n%100==0:
                print(n)
        g.run("match (a: Person {name :"+data[i]+"}) set a.circle_num = "+str(len(data)))