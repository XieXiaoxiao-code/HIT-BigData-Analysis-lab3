from py2neo import Graph, Node, Relationship
g = Graph("bolt://localhost:7687", auth = ("neo4j", "010403"))
path = "C:/Users/xiexiaoxiao/Desktop/facebook/"
featname = []
num = []
for line in open(path+"0.featnames"):
    feat = ""
    num.append(line.split(" ")[3])
    line = line.split(" ")[1].split(";")
    for i in range(len(line)-1):
        feat = feat + "_"+line[i]
    feat = feat[1:]
    featname.append(feat)
j = 0
with open(path+"0.egofeat") as f:
    data = f.readline().split("\n")[0].split(" ")
    cypher_language = "merge (a:Person{name:0}) "
    past = featname[0]
    now = featname[0]
    F = []
    print(data)
    for i in range(0, len(data)):
        now = featname[i]
        if past != now:
            if len(F)>1:
                cypher_language = cypher_language + " set a."+past+"="+str(F)
            elif len(F) == 1:
                cypher_language = cypher_language + " set a."+past+"="+str(F[0])
            past = now
            F = []

        if data[i] == "1":
            F.append(str(num[i]).replace("\n", ""))
            if i == 224:
                cypher_language = cypher_language + " set a."+featname[i]+"="+str(F[0])

    g.run(cypher_language)

for line in open(path+"0.feat"):
    data = line.split("\n")[0].split(" ")
    cypher_language = "merge (a:Person{name:"+data[0]+"}) "
    past = featname[0]
    now = featname[0]
    F = []
    for i in range(1, len(data)):
        now = featname[i-1]
        if past != now:
            if len(F)>1:
                cypher_language = cypher_language + " set a."+past+"="+str(F)
            elif len(F) == 1:
                cypher_language = cypher_language + " set a."+past+"="+str(F[0])
            past = now
            F = []

        if data[i] == "1":
            F.append(str(num[i-1]).replace("\n", ""))
            if i == 224:
                cypher_language = cypher_language + " set a."+featname[i-1]+"="+str(F[0])

    j=j+1
    print(j)
    g.run(cypher_language)
    print(cypher_language)
    g.run("merge (a:Person {name:0}) \n merge (b:Person{name:"+data[0]+"}) \n merge (a)-[:Be_Friend_With]->(b)")